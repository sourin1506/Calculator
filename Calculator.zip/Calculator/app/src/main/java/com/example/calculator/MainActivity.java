package com.example.calculator;

import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {




    Button btn_1, btn_2, btn_3,btn_sign, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0, btn_Add, btn_Sub, btn_Mul, btn_Div, btn_calc, btn_clear,btn_Dot,btn_Del,btn_Ans,btn_Prefix;
    EditText ed1, ed2, ed3;
    String S = null;
    double x,Value1, Value2;

    int  c = 0,z=0,ans=0,change=0,next=0;
    boolean mAddition, mSubtract, mMultiplication, mDivision;
   int ans1=0;//used in prefix

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView T=findViewById(R.id.txt_vw);


                    Animation animation1 =
                            AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fading);
                    T.startAnimation(animation1);









        btn_0 = (Button) findViewById(R.id.btn_0);
        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_2 = (Button) findViewById(R.id.btn_2);
        btn_3 = (Button) findViewById(R.id.btn_3);
        btn_4 = (Button) findViewById(R.id.btn_4);
        btn_5 = (Button) findViewById(R.id.btn_5);
        btn_6 = (Button) findViewById(R.id.btn_6);
        btn_7 = (Button) findViewById(R.id.btn_7);
        btn_8 = (Button) findViewById(R.id.btn_8);
        btn_9 = (Button) findViewById(R.id.btn_9);
        btn_Add = (Button) findViewById(R.id.btn_add);
        btn_Div = (Button) findViewById(R.id.btn_div);
        btn_Sub = (Button) findViewById(R.id.btn_sub);
        btn_Mul = (Button) findViewById(R.id.btn_mul);
        btn_calc = (Button) findViewById(R.id.btn_calc);
        btn_sign = (Button) findViewById(R.id.btn_sign);
        btn_clear = (Button) findViewById(R.id.btn_clear);
        btn_Dot = (Button) findViewById(R.id.btn_dot);
        btn_Ans = (Button) findViewById(R.id.btn_ans);
        btn_Prefix = (Button) findViewById(R.id.btn_prefix);
        btn_Del = (Button) findViewById(R.id.btn_del);
        ed1 = (EditText) findViewById(R.id.ed1);
        ed2 = (EditText) findViewById(R.id.ed2);
        ed3 = (EditText) findViewById(R.id.ed3);
        btn_sign.setBackgroundColor(Color.TRANSPARENT);


        btn_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)//to enter text in ed1
                {
                    ed1.setText(ed1.getText() + "0");
                    z = 0;//to indicate which value to be deleted
                    ans1=1;//prefix to indicate if any value is entered or not
                    ans=0;//used in delete operations
                }
                else {
                    ans1 = 1;

                    ed3.setText(ed3.getText() + "0");
                }
                  }
        });


        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "1");
                    z = 0;
                    ans1=1;
                    ans=0;

                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "1");
                }

            }
        });

        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "2");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else
                {
                    ans1=1;
                    ed3.setText(ed3.getText() + "2");
                    }

            }
        });

        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "3");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;

                    ed3.setText(ed3.getText() + "3");
                }
            }
        });

        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "4");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "4");
                }
            }
        });

        btn_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "5");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "5");
                }

            }
        });

        btn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "6");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "6");
                }
            }
        });

        btn_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "7");
                    z = 0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;

                    ed3.setText(ed3.getText() + "7");
                }

            }
        });

        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1) {
                    ed1.setText(ed1.getText() + "8");
                        z=0;
                    ans1=1;
                    ans=0;
                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "8");
                }

            }
        });


        btn_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + "9");
                    z = 0;
                    ans1=1;
                    ans=0;

                }
                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + "9");
                }

            }
        });
        btn_Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c==1)
                {
                    ed1.setText(ed1.getText() + ".");
                    z = 0;
                    ans1=1;
                    ans=0;
                }

                else {
                    ans1 = 1;
                    ed3.setText(ed3.getText() + ".");
                }
            }
        });

        btn_Del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if((z==1)) {
                    ans=0;

                    ed2.setText("");
                    z = 0;
                    next=0;
                    if(ed2.getText().toString().compareTo("")==0)
                        c=0;

                }
                 else if((c == 1)&&(ans==0)) {
                    ed1.setText(ed1.getText().toString().substring(0,((ed1.getText().toString().length())-1)));
                    if(ed1.getText().toString().compareTo("")==0)
                    {
                        z = 1;

                    }
                    else z=0;


                }
                else if((c==0)&&(ans==0))
                {
                    if ((ed1.getText().toString().compareTo("") == 0) && ((ed2.getText().toString().compareTo("") == 0)) && (ed3.getText().toString().compareTo("") == 0))
                     Toast.makeText(MainActivity.this, "No value present", Toast.LENGTH_SHORT).show();

                     else
                     ed3.setText(ed3.getText().toString().substring(0, ((ed3.getText().toString().length()) - 1)));

                }



                    else if(ans==1)
                    {
                       ed3.setText("");
                       c=0;
                       ans=0;

                    }




                }





        });
        btn_Prefix.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {

                                              if (ed3.getText().toString().compareTo("") == 0)
                                                  ed3.setText("-");
                                              else if (ed1.getText().toString().compareTo("") == 0)
                                              {
                                                  if(ed2.getText().toString().compareTo("") != 0) {
                                                      c = 1;
                                                      ans=0;
                                                      z=0;
                                                      ans1=0;
                                                      ed1.setText("-");
                                                  }
                                                  else
                                                      Toast.makeText(MainActivity.this, "Enter a operator first", Toast.LENGTH_SHORT).show();
                                              }

                                          }
                                      });



        btn_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ed3.getText().toString().compareTo("")==0)
                    ans1=0;

                if(ans1==0)
                    Toast.makeText(MainActivity.this, " First enter a Value", Toast.LENGTH_SHORT).show();

                else {
                        if((ed3.getText().toString().compareTo(".")==0) )
                            Toast.makeText(MainActivity.this, " Dot is not a value", Toast.LENGTH_SHORT).show();
                        else {
                            if(next==1)
                                Toast.makeText(MainActivity.this, " Cant add 2 operator at a time", Toast.LENGTH_SHORT).show();
                            else {

                                ed2.setText(ed2.getText() + "+");
                                Value1 = Double.parseDouble(ed3.getText() + "");
                                mAddition = true;
                                z = 1;
                                c = 1;
                                next = 1;
                            }
                        }
                }










            }
        });

        btn_Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ed3.getText().toString().compareTo("")==0)
                    ans1=0;

                if(ans1==0)
                    Toast.makeText(MainActivity.this, " First enter a Value", Toast.LENGTH_SHORT).show();

                else {
                    if((ed3.getText().toString().compareTo(".")==0) )
                        Toast.makeText(MainActivity.this, " Dot is not a value", Toast.LENGTH_SHORT).show();
                    else {
                        if(next==1)
                            Toast.makeText(MainActivity.this, " Cant add 2 operator at a time", Toast.LENGTH_SHORT).show();
                        else {
                            ed2.setText(ed2.getText() + "-");
                            Value1 = Double.parseDouble(ed3.getText() + "");
                            mSubtract = true;
                            z = 1;
                            c = 1;
                            next = 1;
                        }
                    }
                }


            }
        });

        btn_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed3.getText().toString().compareTo("")==0)
                    ans1=0;

                if(ans1==0)
                    Toast.makeText(MainActivity.this, " First enter a Value", Toast.LENGTH_SHORT).show();

                else {
                    if((ed3.getText().toString().compareTo(".")==0) )
                        Toast.makeText(MainActivity.this, " Dot is not a value", Toast.LENGTH_SHORT).show();
                    else {
                        if(next==1)
                            Toast.makeText(MainActivity.this, " Cant add 2 operator at a time", Toast.LENGTH_SHORT).show();
                        else {

                            ed2.setText(ed2.getText() + "*");
                            Value1 = Double.parseDouble(ed3.getText() + "");
                            mMultiplication = true;
                            z = 1;
                            c = 1;
                            next = 1;
                        }
                    }
                }

            }
        });

        btn_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed3.getText().toString().compareTo("")==0)
                    ans1=0;

                if(ans1==0)
                    Toast.makeText(MainActivity.this, " First enter a Value", Toast.LENGTH_SHORT).show();

                else {
                    if((ed3.getText().toString().compareTo(".")==0) )
                        Toast.makeText(MainActivity.this, " Dot is not a value", Toast.LENGTH_SHORT).show();
                    else {
                        if(next==1)
                            Toast.makeText(MainActivity.this, " Cant add 2 operator at a time", Toast.LENGTH_SHORT).show();
                        else {

                            ed2.setText(ed2.getText() + "/");
                            Value1 = Double.parseDouble(ed3.getText() + "");
                            mDivision = true;
                            z = 1;
                            c = 1;
                            next = 1;
                        }
                    }
                }

            }
        });

        btn_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if ((ed3.getText().toString().compareTo("") == 0) || (ed1.getText().toString().compareTo("") == 0))
                    ans1 = 0;

                if (ans1 == 0)
                {
                    Toast.makeText(MainActivity.this, " First enter a Value", Toast.LENGTH_SHORT).show();
                    ans1=1;
                }

                else {

                    if ((ed1.getText().toString().compareTo(".") == 0))
                        Toast.makeText(MainActivity.this, " Dot is not a value", Toast.LENGTH_SHORT).show();

                    else {
                        Value2 = Double.parseDouble(ed1.getText() + "");
                        Intent i = new Intent(MainActivity.this, Main2Activity.class);
                        if (mAddition == true) {


                            x = Value1 + Value2;

                            mAddition = false;
                        }


                        if (mSubtract == true) {
                            x = Value1 - Value2;
                            mSubtract = false;

                        }

                        if (mMultiplication == true) {
                            x = Value1 * Value2;
                            mMultiplication = false;
                        }

                        if (mDivision == true) {
                            x = Value1 / Value2;

                            mDivision = false;
                        }

                        ed2.setText("");
                        S = Double.toString(x);

                            i.putExtra("Value", S);

                            ed3.setText(S);
                            ed1.setText("");
                            ans = 1;
                            next=0;
                            startActivity(i);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);


                    }
                }
            }
        });

        btn_Ans.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           ed3.setText(S);
                                           ans=1;
                                           next=0;
                                       }
                                   });
        btn_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed1.setText("");
                ed2.setText("");
                ed3.setText("");
                z=0;
                c = 0;
                ans=0;
                change=0;
                next=0;
            }
        });
        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(MainActivity.this, Main3Activity.class);
                startActivity(j);

                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);


            }
        });



    }


}


