package com.example.calculator;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Intro extends AppCompatActivity {

    private static int SPLASH_TIME = 2000; //This is 4 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        ImageView image = (ImageView)findViewById(R.id.img_veiw);
        Animation animation1 =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade);
        image.startAnimation(animation1);



        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //Do any action here. Now we are moving to next page
                Intent mySuperIntent = new Intent(Intro.this, MainActivity.class);
                mySuperIntent.putExtra("id", "1");

                startActivity(mySuperIntent);

                /* This 'finish()' is for exiting the app when back button pressed
                 *  from Home page which is ActivityHome
                 */
               Intro.this.finish();
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                finish();
            }
        }, SPLASH_TIME);
    }
}
